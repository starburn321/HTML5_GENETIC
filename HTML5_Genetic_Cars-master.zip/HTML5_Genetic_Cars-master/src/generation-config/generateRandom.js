
module.exports = generateRandom;
function generateRandom(){
  return Math.random();
}
